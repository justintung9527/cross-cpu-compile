#ifndef __ASM_GENERIC_SHMPARAM_H
#define __ASM_GENERIC_SHMPARAM_H

#define SHMLBA PAGE_SIZE	 /* attach addr a multiple of this */

#endif /* _ASM_GENERIC_SHMPARAM_H */
